package comparisonmethod;

public interface ComparisonMethod {

	public double compare(String file1, String file2, String options) throws Exception;
}
