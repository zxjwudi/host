package comparisonmethod;

import java.io.File;
import java.io.IOException;

import mojo.MoJoCalculator;

public class MoJoMethod implements ComparisonMethod {

	public MoJoMethod() {
		super();
	}

	/**
	 * Compare two input files (file1, file2) using the mojo algorithm
	 * with (options). 
	 * 
	 * @param fileName1		The input file1.
	 * @param fileName2 	The input file2.
	 * @param options	The compare options.
	 * 
	 * @return 			The compare result.
	 * 
	 * @exception IOException	
	 */
	public double compare(String fileName1, String fileName2, String options) throws IOException {

		// Obtain the two input files
		File f1 = new File(fileName1);
		File f2 = new File(fileName2);
        
        MoJoCalculator mjc = new MoJoCalculator(f1.getAbsolutePath(), f2.getAbsolutePath(), null);

        return mjc.mojo();
        
//		// Command line to invoke the external mojo algorithm
//		String cmd = "java -jar mojo.jar";
//		if (options != null)
//			cmd = cmd + " " + options;
//		cmd = cmd + " " + f1.getAbsolutePath() + " " + f2.getAbsolutePath();
//
//		/*
//		 * Create a child process, let it run the command.
//		 * Intercept the result from the child process output.
//		 */
//		Runtime runtime = Runtime.getRuntime();
//		Process proc = runtime.exec(cmd);
//		InputStream inputstream = proc.getInputStream();
//		InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
//		BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
//
//		/*
//		 * Read each line from the child process output
//		 * and put it into a vector.
//		 */
//		String line = null;
//		Vector<String> output = new Vector<String>();
//		while ((line = bufferedreader.readLine()) != null)
//			output.add(line);
//		
//		/*
//		 * For mojo algorithm result, the compare result
//		 * locates at the last position in the last line
//		 * of the output.
//		 */
//		StringTokenizer st = new StringTokenizer(output.lastElement());
//		int num = st.countTokens();
//		for (int i = 0; i < num - 1; i++) 
//			st.nextToken();
//		String result = (st.nextToken()).trim();
//		
//		// Compare result
//		double number = 0;
//		
//		// Process the result if it is a percentage number
//		if ((result.charAt(result.length() - 1)) == '%') {
//			result = result.substring(0, result.length() - 1);
//			if (result.indexOf('.') != -1)
//				number = Double.parseDouble(result) / 100.00;
//			else
//				number = Integer.parseInt(result) / 100.00;
//		} 
//		// Process the result if it is a double
//		else if (result.indexOf('.') != -1) 	
//			number = Double.parseDouble(result);
//		// Process the result if it is a int.
//		else	
//			number = Integer.parseInt(result) / 1.00;
//		
//		/* NumberFormatException may occur if the result is not
//		 * a number. If the mojo algorithm fails to compare two
//		 * file, an error message is thrown. The last position in 
//		 * the last line of the output is not a number any more.
//		 */
//		return number;		
	}
}