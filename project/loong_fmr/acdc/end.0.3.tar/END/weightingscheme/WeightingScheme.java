package weightingscheme;

import java.util.Vector;

public interface WeightingScheme {

	public final int DECIMAL_PLACE = 2;
	
	public double weight(Vector<Double> sv);
}
