package weightingscheme;

import java.math.BigDecimal;
import java.util.Vector;

public class FirstElementScheme implements WeightingScheme {

	public FirstElementScheme() {
		super();
	}
	
	/**
	 * Weight a vector of doubles using FirstElement
	 * Scheme.
	 * 
	 * @param	A vector of doubles.
	 * @return  The weighting result.
	 */
	public double weight(Vector<Double> sv) {
		int n = sv.size();
		double item = 0;
		double total = 0;
		double result = 0;
		
		for (int i = 1; i <= n; i++) {
			int index = i - 1;
		
			// x0 is the first element
			if (index == 0) {
				double x0 = sv.firstElement();
				item = (x0 * x0) * (2.0 / (n + 1.0));
			} else {	
				double xi = sv.elementAt(index);
				item = (xi * xi) * (1.0 / (n + 1.0));
			}
			
			total = total + item;
		}
		result = Math.sqrt(total);
		
		BigDecimal bd = new BigDecimal(result);
		bd = bd.setScale(DECIMAL_PLACE,BigDecimal.ROUND_UP);
		return bd.doubleValue();
	}
}
