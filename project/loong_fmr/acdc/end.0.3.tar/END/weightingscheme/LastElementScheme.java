package weightingscheme;

import java.math.BigDecimal;
import java.util.Vector;

public class LastElementScheme implements WeightingScheme {
	
	public LastElementScheme() {
		super();
	}
	
	/**
	 * Weight a vector of doubles using LastElement
	 * Scheme.
	 * 
	 * @param	A vector of doubles.
	 * @return  The weighting result.
	 */
	public double weight(Vector<Double> sv) {
		int n = sv.size();
		double item = 0;
		double total = 0;
		double result = 0;
		
		for (int i = 1; i <= n; i++) {
			int index = i - 1;
		
			// xn is the last element
			if (index == n - 1) {
				double xn = sv.lastElement();
				item = (xn * xn) * (2.0 / (n + 1.0));	
			}else {
				double xi = sv.elementAt(index);
				item = (xi * xi) * (1.0 / (n + 1.0));
			}
			
			total = total + item;
		}
		result = Math.sqrt(total);
		
		BigDecimal bd = new BigDecimal(result);
		bd = bd.setScale(DECIMAL_PLACE,BigDecimal.ROUND_UP);
		return bd.doubleValue();
	}
}
