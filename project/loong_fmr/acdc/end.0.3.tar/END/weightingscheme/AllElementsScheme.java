package weightingscheme;

import java.math.BigDecimal;
import java.util.Vector;

public class AllElementsScheme implements WeightingScheme {

	public AllElementsScheme() {
		super();
	}

	/**
	 * Weight a vector of doubles using AllElements
	 * Scheme.
	 * 
	 * @param	A vector of doubles.
	 * @return  The weighting result.
	 */
	public double weight(Vector<Double> sv) {
		int n = sv.size();
		double item = 0;
		double total = 0;
		double result = 0;
		
		for (int i = 1; i <= n; i++) {
			int index = i - 1;
			double xi = sv.elementAt(index);
			item = (xi * xi) * (1.0 / n);
			total = total + item;
		}
		result = Math.sqrt(total);
		
		BigDecimal bd = new BigDecimal(result);
		bd = bd.setScale(DECIMAL_PLACE,BigDecimal.ROUND_UP);
		return bd.doubleValue();
	}
}
