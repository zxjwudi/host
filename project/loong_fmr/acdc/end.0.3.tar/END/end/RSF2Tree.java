package end;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.swing.tree.DefaultMutableTreeNode;

public class RSF2Tree {

	// The source rsf file name.
	private String in_file;
	
	/**
	 * Construct a transfomer which transforms the
	 * source rsf file to a tree. 
	 * 
	 * @param a_file	The source rsf file name.
	 */
	public RSF2Tree(String a_file) {
		in_file = a_file;
	}
	
	/**
	 * Transform the source rsf file to a tree.
	 * Reads the decomposition from the source rsf file
	 * and transforms it into a tree.
	 * 
	 * @return	The root of a tree.
	 * 
	 * @throws IOException
	 */
	public DefaultMutableTreeNode rsf2tree() throws IOException  {
		
		DefaultMutableTreeNode result = new DefaultMutableTreeNode(in_file);
		
		//	The source rsf file reader.
		BufferedReader in = new BufferedReader(new FileReader(in_file));
		
		String line = in.readLine();
		while (line != null) {
			line = line.trim();
			// Follow the format "contain cluster object". 
			StringTokenizer token = new StringTokenizer(line);
			@SuppressWarnings("unused")
			// Skip the token (contain).
			String first_token = token.nextToken();	
			String second_token = token.nextToken();
			String third_token = token.nextToken();
			/* 
			 * Cluster is the parent of a object.
			 * Therefore, cluster != object. 
			 */
			if (second_token.equals(third_token))
				throw new IllegalArgumentException("A node can not be the child of itself!");
			
			DefaultMutableTreeNode root = (DefaultMutableTreeNode) result.getRoot();
			Enumeration allNodes = root.depthFirstEnumeration();
			
			DefaultMutableTreeNode tok2 = null;
			DefaultMutableTreeNode tok3 = null;

			/*
			 * Examine all existing nodes in the tree
			 * to check whether second_token or third
			 * _token is in the tree.
			 */
			while (allNodes.hasMoreElements()) {
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) allNodes.nextElement();
				/*
				 * If a node's user object is equal to
				 * one of the tokens (second_token, third_token),
				 * it is already in the tree.
				 */
				String item = (String) node.getUserObject();
				if (item.equalsIgnoreCase(second_token))
					tok2 = node;
				if (item.equalsIgnoreCase(third_token))
					tok3 = node;
			}

			/*
			 * Second_token is not in the tree.
			 * Create a tree node of second_token and
			 * add it into the root.
			 */
			if (tok2 == null) {
				tok2 = new DefaultMutableTreeNode(second_token);
				root.add(tok2);
			}

			/*
			 * Third_token is not tree.
			 * Create a tree node of third_token.
			 */
			if (tok3 == null)
				tok3 = new DefaultMutableTreeNode(third_token);
			
			/*
			 * According to the format, second_token
			 * is the parent of third_token.
			 * Add third_token as the child to second
			 * _token.
			 */
			tok2.add(tok3);
			line = in.readLine();
		}
		in.close();		
		return result;
	}
}
