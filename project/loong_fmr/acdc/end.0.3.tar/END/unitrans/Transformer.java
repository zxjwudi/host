package unitrans;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public abstract class Transformer {

	// The input file reader.
	protected BufferedReader input;	
	// The output file writer.
	protected PrintWriter output;
	
	/**
	 * Construct a buffered reader for the input file
	 * and a print writer for the output file.
	 * 
	 * @param in			The input file name.
	 * @param out			The output file name.
	 * @throws IOException		
	 */
	public Transformer (String in, String out) throws IOException  {
		input = new BufferedReader(new FileReader(in));		
	 	output = new PrintWriter(new BufferedWriter(new FileWriter(out)));
	}
	
	/**
	 * Read the input file opened by the buffered reader.
	 * @throws IOException
	 */
	abstract public void read_input() throws IOException;
	
	/**
	 * Write to the output file opened by the print writer.
	 */
	abstract public void write_output();
}