package unitrans;

import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

public class SIL2RSF extends Transformer {

	// The vector of facts.
	private Vector<Fact> facts;
	
	/**
	 * Construct a transformer from sil to rsf with the
	 * source sil file name and target rsf file name. 
	 * 
	 * @param in	The source sil file name.
	 * @param out	The target rsf file name.
	 * @throws IOException
	 */
	public SIL2RSF(String in, String out) throws IOException {
		super(in, out);
		facts = new Vector<Fact>();
	}
	
	/**
	 * Read the input RSF file and collect all the facts.
	 *  
	 */
	public void read_input() throws IOException {
		String line = input.readLine();
		while (line != null) {
			int start = 3;
			int end = line.indexOf(')');
			String cluster = line.substring(start, end);
			String header = new String("SS(" + cluster + ") = ");
			String factline = line.substring(header.length());
			StringTokenizer tok = new StringTokenizer(factline);
			
			while(tok.hasMoreTokens()) {
				String target = tok.nextToken();
				target.trim();
				if (target.endsWith(","))
					target = target.substring(0, target.length()-1);
				Fact f = new Fact();
				f.setSource(cluster);
				f.setTarget(target);
				facts.addElement(f);
			}
			line = input.readLine();
		}
	}
	
	/**
	 * Write into the target rsf file with the facts 
	 * read from the source sil file. 
	 */
	public void write_output () {
		Iterator<Fact> ifacts = facts.iterator();
		while (ifacts.hasNext()) {
			Fact f = ifacts.next();
			String result = new String("contain ");
			result = result.concat(f.getSource() + " " + f.getTarget());
			output.println(result);
		}		
		output.close();
	}
}
