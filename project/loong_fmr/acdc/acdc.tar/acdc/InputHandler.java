package acdc;
import javax.swing.tree.DefaultMutableTreeNode;

public interface InputHandler
{
	public void readInput(String inputStr, DefaultMutableTreeNode treeModel);
}
